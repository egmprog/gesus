<div class="notification is-danger is-light mb-6 mt-6">
    <strong>¡Ocurrio un error inesperado!</strong><br>
    No podemos obtener la información solicitada
</div>