<div class="container is-fluid">
    <h1 class="title">Home</h1>
    <h2 class="subtitle">¡Bievenido <?php echo $_SESSION['nombre']." ".$_SESSION['apellido'];?>!</h2>
</div>